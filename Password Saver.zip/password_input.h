#ifndef password_input_h
#define    password_input_h

class password_in{
	public:
		void pass_in();
		void pass_show();
};


#endif
