#include<windows.h>
using namespace std;

void p(){
			MessageBox(NULL,"Password Saver","Made by Huzaifa",MB_OK);

}
